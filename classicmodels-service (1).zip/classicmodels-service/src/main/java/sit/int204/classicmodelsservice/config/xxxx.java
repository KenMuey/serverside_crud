package sit.int204.classicmodelsservice.config;

public class xxxx {
}
